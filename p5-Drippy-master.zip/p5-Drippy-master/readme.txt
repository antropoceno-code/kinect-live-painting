 Memo Akten | www.memo.tv | 2008
 
 SPACE - clear screen
C - change screen clearing mode (CLEAR, FADE, ACCUMULATE)
B - branching mode (NO BRANCHING, SCARY, DRIPPY)
M - mouse mode ON/OFF (follows mouse or not)
S - toggle travel speed between FAST / SLOW
N - randomize number of branches
1 - 6 - Choose a preset of all above parameters and other numbers
1 - Bacteria
2 - Scary Branches
3 - Drippy Branches
4 - Lone Sperm
5 - Drippy Paint (use mouse to draw on canvas)
6 - Scary Paint (use mouse to draw on canvas)

Built with Processing